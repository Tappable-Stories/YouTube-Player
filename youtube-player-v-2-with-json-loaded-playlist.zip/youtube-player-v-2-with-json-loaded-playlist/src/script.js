let player;
let autoplayEnabled = true; // Default autoplay setting

/**
 * Loads the YouTube IFrame API dynamically if not already loaded.
 */
function loadYouTubeAPI() {
  if (!window.YT) {
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
  } else {
    onYouTubeIframeAPIReady();
  }
}

/**
 * Initializes the playlist by calling `loadPlaylist()`
 * Ensures execution only if the video player exists.
 */
function initializePlaylist() {
  if (document.querySelector("#video-player")) {
    loadPlaylist();
  }
}

/**
 * Reinitializes the player after an AJAX call.
 * Clears the existing player, reloads the YouTube API, and resets the playlist.
 */
function reinitializePlayer() {
  console.log("Reinitializing YouTube Player...");

  // Remove the existing YouTube iframe if it exists
  const iframe = document.querySelector("#YouTube-Iframe");
  if (iframe) {
    iframe.remove();
  }

  // Clear the playlist UI
  const playlistContainer = document.querySelector("#playlist");
  if (playlistContainer) {
    playlistContainer.innerHTML = "";
  }

  // Reload the YouTube API only if necessary
  if (typeof YT === "undefined" || typeof YT.Player === "undefined") {
    loadYouTubeAPI();
  } else {
    initializePlaylist();
  }
}

/**
 * Callback function for YouTube IFrame API when ready.
 */
function onYouTubeIframeAPIReady() {
  initializePlaylist();
}

/**
 * Event handler when the YouTube player is ready.
 */
function onPlayerReady(event) {
  console.log("YouTube Player is ready");
}

/**
 * Detects when a video ends and automatically plays the next one if autoplay is enabled.
 */
function onPlayerStateChange(event) {
  if (event.data === YT.PlayerState.ENDED && autoplayEnabled) {
    playNextVideo();
  }
}

/**
 * Plays the next video in the playlist.
 * If the last video ends, loops back to the first video.
 */
function playNextVideo() {
  const buttons = document.querySelectorAll("#playlist button");
  let activeButton = document.querySelector("#playlist button.active");

  if (!buttons.length) return;

  let currentIndex = activeButton
    ? Array.from(buttons).indexOf(activeButton)
    : -1;
  let nextIndex = currentIndex + 1;

  if (activeButton && activeButton.classList.contains("last-video")) {
    nextIndex = 0; // Loop back to the first video if at the last
  }

  if (buttons[nextIndex]) {
    buttons[nextIndex].click();
    scrollToActiveButton(); // Move the next button flush left
  }
}

/**
 * Loads the playlist from a JSON file and dynamically populates the UI.
 */
function loadPlaylist() {
  const playlistContainer = document.querySelector("#playlist");
  const videoPlayer = document.querySelector("#video-player");

  if (!playlistContainer || !videoPlayer) return; // Prevents errors if elements are missing

  const playlistPath = videoPlayer.getAttribute("data-playlist");
  if (!playlistPath) return;

  fetch(playlistPath)
    .then((response) => response.json())
    .then((data) => {
      playlistContainer.innerHTML = "";

      // Apply player container class from JSON
      if (data.class) {
        videoPlayer.className = data.class;
      }

      if (data.videos.length > 0) {
        const firstVideo = data.videos[0];

        // Create and insert YouTube iframe
        const iframe = document.createElement("iframe");
        iframe.id = "YouTube-Iframe";
        iframe.setAttribute("loading", "lazy");
        iframe.setAttribute(
          "src",
          `https://www.youtube.com/embed/${firstVideo.id}?enablejsapi=1&autoplay=1`
        );
        iframe.setAttribute("frameborder", "0");
        iframe.setAttribute(
          "allow",
          "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        );
        iframe.setAttribute("allowfullscreen", "");
        videoPlayer.prepend(iframe);

        // Set the first video caption
        const captionContainer = document.querySelector("#video-caption");
        if (captionContainer) captionContainer.innerHTML = firstVideo.caption;

        // Initialize the player
        player = new YT.Player("YouTube-Iframe", {
          events: {
            onReady: onPlayerReady,
            onStateChange: onPlayerStateChange
          }
        });
      }

      data.videos.forEach((video, index) => {
        const button = document.createElement("button");
        button.setAttribute("data-youtube", video.id);
        button.setAttribute("data-caption", video.caption);

        // Use custom thumbnail if available, else use YouTube default
        const thumbnail = video.thumbnail
          ? video.thumbnail
          : `https://img.youtube.com/vi/${video.id}/sddefault.jpg`;
        button.style.backgroundImage = `url('${thumbnail}')`;

        button.textContent = video.title;

        if (index === 0) {
          button.classList.add("active");
        }

        if (index === data.videos.length - 1) {
          button.classList.add("last-video");
        }

        button.addEventListener("click", updateVideo);
        playlistContainer.appendChild(button);
      });

      scrollToActiveButton();
    })
    .catch((error) => console.error("Error loading playlist:", error));
}

/**
 * Scrolls the active video button into view.
 */
function scrollToActiveButton() {
  const activeButton = document.querySelector("#playlist button.active");
  const playlistContainer = document.querySelector("#playlist");

  if (activeButton && playlistContainer) {
    const buttonOffset = activeButton.offsetLeft;

    playlistContainer.scrollTo({
      left: buttonOffset - 10, // Move it to the left edge with a slight margin
      behavior: "smooth"
    });
  }
}

/**
 * Updates the YouTube player with the selected video.
 */
function updateVideo() {
  const videoId = this.getAttribute("data-youtube");
  const caption = this.getAttribute("data-caption");

  const captionContainer = document.querySelector("#video-player #video-caption");
  if (captionContainer) captionContainer.innerHTML = caption;

  if (player && videoId) {
    player.loadVideoById(videoId);
    player.playVideo(); // Ensure video starts playing
  }

  document.querySelectorAll("#playlist button").forEach((btn) => btn.classList.remove("active"));
  this.classList.add("active");

  scrollToActiveButton();
}

/**
 * Toggles autoplay on/off.
 */
function toggleAutoplay() {
  autoplayEnabled = !autoplayEnabled;
  const autoplayState = document.querySelector("#autoplay-state");
  if (autoplayState) autoplayState.textContent = autoplayEnabled ? "ON" : "OFF";
}

// Initialize the player only if the #video-player container exists
document.addEventListener("DOMContentLoaded", () => {
  if (document.querySelector("#video-player")) {
    loadYouTubeAPI();
  }

  // Add autoplay toggle container only if video player exists
  const videoPlayer = document.querySelector("#video-player");
  if (videoPlayer) {
    const toggleContainer = document.createElement("div");
    toggleContainer.id = "autoplay-container";
    toggleContainer.style.textAlign = "center";

    const toggleButton = document.createElement("button");
    toggleButton.id = "autoplay-toggle";
    toggleButton.innerHTML = "Autoplay: <span id='autoplay-state'>ON</span>";
    toggleButton.addEventListener("click", toggleAutoplay);

    toggleContainer.appendChild(toggleButton);
    videoPlayer.appendChild(toggleContainer);
  }

  // **Mousewheel Scroll for Playlist**
  const scrollContainer = document.querySelector("#playlist");
  if (scrollContainer) {
    scrollContainer.removeEventListener("wheel", scrollPlaylist);
    scrollContainer.addEventListener("wheel", scrollPlaylist);
  }

  function scrollPlaylist(evt) {
    evt.preventDefault();
    scrollContainer.scrollLeft += evt.deltaY;
  }
});

// The Switcher. Just for Demo
function setPlayerTheme(theme) {
  const player = document.querySelector("#video-player");
  player.className = theme ? theme : "";
  console.log(`Theme changed to: ${theme}`);
}

// Listen for theme selection
document
  .querySelector("#theme-selector")
  .addEventListener("change", function () {
    setPlayerTheme(this.value);
  });
