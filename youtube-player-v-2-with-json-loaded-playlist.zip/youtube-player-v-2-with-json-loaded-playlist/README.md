# 🎬 YouTube Player V. 2 with JSON Loaded Playlist  🎬 

A Pen created on CodePen.

Original URL: [https://codepen.io/mark_sottek/pen/ogNZKvo](https://codepen.io/mark_sottek/pen/ogNZKvo).

🎬 YouTube Player with JSON Loaded Playlist - Version Two 🎬

This updated pen enhances the dynamic YouTube playlist experience with new features for better customization and styling.

🚀  What's New in Version Two?

✅  Custom Player Class: The video-player container now dynamically applies a class from the JSON file, allowing for easy styling and theme customization.

✅  Thumbnail Override Support: Each video entry can specify a custom thumbnail image in the JSON file. If provided, it replaces the default YouTube thumbnail.

🎥  Core Features:

✅  Loads the playlist from JSON and generates video buttons dynamically.
✅  Initializes the YouTube Player API, setting the first video as the default.
✅  Updates the player and caption when a button is clicked—no refresh required.
✅  Auto-advances to the next video when one ends, looping back to the first when the last video finishes.
✅  Includes an autoplay toggle, allowing users to enable or disable continuous playback.
✅  Scrolls horizontally on hover, ensuring a sleek and interactive UI.

The core logic is driven by data attributes and the YouTube IFrame API, making it easy to manage and scale with new videos by simply updating the JSON file.

🎨  Styling made easy—define a unique class in JSON and apply it automatically!

🖼️  Custom thumbnails? No problem! Override YouTube's default image with your own.